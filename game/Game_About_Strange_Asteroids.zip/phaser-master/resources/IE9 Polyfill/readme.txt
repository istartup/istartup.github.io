The polyfill found in this folder provides ArrayBuffer and DataView support for IE9, required by P2 Physics.

You do not need this polyfill unless:

1) You are using P2 Physics in Phaser AND
2) You need to support IE9 specifically

Ensure the polyfill is required before the Phaser library.
